import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.*;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

public class PrepararMensajeMQ extends MbJavaComputeNode {

    public void evaluate(MbMessageAssembly assembly) throws MbException {
        MbMessage inputMessage = assembly.getMessage();
        MbMessageAssembly outAssembly = null;

        try {
            MbMessage outMessage = new MbMessage(inputMessage);
            outAssembly = new MbMessageAssembly(assembly, outMessage);

            MbMessage env = assembly.getGlobalEnvironment();
            MbElement rootEnv = env.getRootElement();
            
            MbElement requestOriginal = rootEnv.getFirstElementByPath("Variables/RequestOriginal");
            String correlationId = rootEnv.getFirstElementByPath("Variables/CorrelationId").getValueAsString();

            String timestampAprobacion = ZonedDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSXXX"));

            MbElement rootElement = outMessage.getRootElement();
            MbElement jsonRoot = rootElement.getFirstElementByPath(MbJSON.PARSER_NAME);
            if (jsonRoot != null) {
                jsonRoot.delete(); 
            }
            jsonRoot = rootElement.createElementAsLastChild(MbJSON.PARSER_NAME);
            MbElement jsonData = jsonRoot.createElementAsLastChild(MbElement.TYPE_NAME, MbJSON.DATA_ELEMENT_NAME, null);

            if (requestOriginal != null) {
                MbElement child = requestOriginal.getFirstChild();
                while (child != null) {
                    jsonData.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, child.getName(), child.getValue());
                    child = child.getNextSibling();
                }
            }

            jsonData.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "correlationId", correlationId);
            jsonData.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "timestampAprobacion", timestampAprobacion);

            MbOutputTerminal outTerminal = this.getOutputTerminal("out");
            outTerminal.propagate(outAssembly);

        } catch (Exception e) {
            throw new MbUserException(this, "evaluate", "", "", e.toString(), null);
        }
    }
}