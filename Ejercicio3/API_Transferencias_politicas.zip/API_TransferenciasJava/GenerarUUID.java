import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbRecoverableException;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;

public class GenerarUUID extends MbJavaComputeNode {

    private static final Logger logger = Logger.getLogger(GenerarUUID.class.getName());

    @Override
    public void evaluate(MbMessageAssembly inAssembly) throws MbException {

        MbOutputTerminal out     = getOutputTerminal("out");
        MbOutputTerminal failure = getOutputTerminal("failure"); 

        MbMessageAssembly outAssembly = null;

        try {
            outAssembly = new MbMessageAssembly(inAssembly, inAssembly.getMessage());

            String uuid = UUID.randomUUID().toString();
            logger.fine("CorrelationId generado: " + uuid);

            MbMessage env     = outAssembly.getGlobalEnvironment();
            MbElement root    = env.getRootElement();

            MbElement variables = root.getFirstElementByPath("Variables");
            if (variables == null) {
                variables = root.createElementAsLastChild(MbElement.TYPE_NAME, "Variables", null);
            }

            MbElement corrEl = variables.getFirstElementByPath("CorrelationId");
            if (corrEl == null) {
                variables.createElementAsLastChild(
                    MbElement.TYPE_NAME_VALUE, "CorrelationId", uuid);
            } else {
                logger.fine("CorrelationId ya exist�a: " + corrEl.getValueAsString());
            }

            out.propagate(outAssembly);

        } catch (MbException mbEx) {
            logger.log(Level.SEVERE, "MbException en GenerarUUID: " + mbEx.getMessage(), mbEx);

            if (failure.isAttached()) {
                failure.propagate(inAssembly);
            } else {
                throw mbEx; 
            }

        } catch (Exception ex) {
            logger.log(Level.SEVERE, "Error inesperado en GenerarUUID: " + ex.getMessage(), ex);

            throw new MbRecoverableException(
                this,
                "GenerarUUID",       
                "evaluate",          
                ex.getMessage(),      
                "GenerarUUID",       
                new Object[]{}        
            );
        } finally {
            outAssembly = null;
        }
    }
}