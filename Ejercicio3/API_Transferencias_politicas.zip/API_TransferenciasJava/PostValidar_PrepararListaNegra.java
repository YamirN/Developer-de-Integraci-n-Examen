import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.*;

public class PostValidar_PrepararListaNegra extends MbJavaComputeNode {

	public void evaluate(MbMessageAssembly assembly) throws MbException {
        MbMessage inputMessage = assembly.getMessage();
        MbMessageAssembly outAssembly = null;

        try {
            MbMessage outMessage = new MbMessage(inputMessage);
            outAssembly = new MbMessageAssembly(assembly, outMessage);

            MbMessage localEnv = assembly.getLocalEnvironment();
            MbElement localEnvRoot = localEnv.getRootElement();

            MbPolicy policy = MbPolicy.getPolicy("UserDefined", "PoliticasSeguridad:PolicyAutenticacion");

            if (policy != null) {
                String tokenEndpoint = policy.getPropertyValueAsString("tokenEndpoint");
                
                MbElement dest = localEnvRoot.getFirstElementByPath("Destination");
                if (dest == null) dest = localEnvRoot.createElementAsLastChild(MbElement.TYPE_NAME, "Destination", null);

                MbElement http = dest.getFirstElementByPath("HTTP");
                if (http == null) http = dest.createElementAsLastChild(MbElement.TYPE_NAME, "HTTP", null);

                MbElement requestURL = http.getFirstElementByPath("RequestURL");
                if (requestURL == null) {
                    http.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "RequestURL", tokenEndpoint);
                } else {
                    requestURL.setValue(tokenEndpoint);
                }
            } else {
                throw new MbUserException(this, "evaluate", "", "", "Error: No se encontr� la pol�tica PoliticasSeguridad:PolicyAutenticacion", null);
            }

            MbOutputTerminal outTerminal = this.getOutputTerminal("out");
            outTerminal.propagate(outAssembly);

        } catch (Exception e) {
            throw new MbUserException(this, "evaluate", "", "", e.toString(), null);
        }
    }
}